import { auth } from '../firebase-config';
... (full auth service code)