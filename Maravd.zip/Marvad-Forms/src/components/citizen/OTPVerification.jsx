import React, { useState, useEffect } from 'react';
... (full OTPVerification code)