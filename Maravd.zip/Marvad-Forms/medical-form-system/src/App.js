import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Medical Form System</h1>
    </div>
  );
}

export default App;